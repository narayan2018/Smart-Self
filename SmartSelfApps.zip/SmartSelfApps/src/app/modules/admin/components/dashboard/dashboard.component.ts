import { Component, OnInit } from '@angular/core';
import { counter } from '@fortawesome/fontawesome-svg-core';
import { Subscription, switchMap, timer } from 'rxjs';
import { HardwareServiceService } from 'src/app/services/hardware-service.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  totalBookReturn: number = 0;
  totalBookRejected: number = 0;
  totalBooks: number = 0;
  private hardwareList: hard[];
  subscription !: Subscription;
  constructor(private _hardwareService: HardwareServiceService) {
    this.hardwareList = [];

  }

  ngOnInit(): void {
    //this.totalBookReturn = 50;
    //this.totalBookRejected = 20;
    // this.totalBooks = this.totalBookReturn + this.totalBookRejected;
    this.GetData();
  }

  GetData() {
    this._hardwareService.getAll().subscribe((data) => {
      this.hardwareList = <hard[]>data;
      console.log(this.hardwareList.length)
      this.CountBooks();
    });

  }
  // GetData() {
  //   this.subscription = timer(0, 10000).pipe(
  //     switchMap(() => this._hardwareService.getAll())
  //   ).subscribe((data: any) => {
  //     console.log("dashboard scanning completed.");
  //     //this.hardwareList=[];
  //     this.hardwareList = <hard[]>data;;
  //     this.CountBooks();
  //   }
  //   );
  // }

  async CountBooks() {
    // console.log(this.hardwareList.length);
    for (let i = 0; i < this.hardwareList.length; i++) {
      if (this.hardwareList[i].checkinstatus === "1") {
        this.totalBookReturn = this.totalBookReturn + 1;
      }
      if (this.hardwareList[i].checkinstatus === "1") {
        this.totalBookRejected = this.totalBookRejected + 1;
      }
      this.totalBooks = this.totalBookReturn + this.totalBookRejected;
      await new Promise(f => setTimeout(f, 200));
    }
  }
}
export interface hard {
  id: number,
  itemCode: string,
  returnDate: string,
  scanedDate: string,
  shelfno: string,
  bayno: string,
  tierno: string,
  itemID: string,
  itemTitle: string,
  checkinstatus: string,
  message: string
}