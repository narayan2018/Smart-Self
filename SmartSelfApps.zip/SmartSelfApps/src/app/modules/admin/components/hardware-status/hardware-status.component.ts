import { Component, OnInit } from '@angular/core';
import { Subscription, switchMap, timer } from 'rxjs';
import { HardwareServiceService } from 'src/app/services/hardware-service.service';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
import { DatePipe, formatDate } from '@angular/common';
import { identifierName } from '@angular/compiler';

@Component({
  selector: 'app-hardware-status',
  templateUrl: './hardware-status.component.html',
  styleUrls: ['./hardware-status.component.css']
})
export class HardwareStatusComponent implements OnInit {
  public hardwareList: any;
  subscription !: Subscription;
  filterList: any = ['All', 'BarCode', 'Title'];
  checkingList: any = ['All', 'Success', 'Failed'];
  filterValue: string = "";
  selectedFilter: any = "";
  selectedCheckingStatus: any = "";
  selectedDate: any;
  fileName = 'ExcelSheet.xlsx';
  fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  fileExtension = '.xlsx';
  datepipe: any;
  constructor(private _hardwareService: HardwareServiceService) {
    datepipe: DatePipe
  }

  ngOnInit(): void {
    this.GetData();
    this.selectedFilter = this.filterList[0];
    this.selectedCheckingStatus = this.checkingList[0];
  }

  private GetData() {
    this._hardwareService.getAll().subscribe((data) => {
      this.hardwareList = data;
      console.log(2);
      this.FilterData();
    });
  }

  OnSearch() {
    // this.datepipe.transform(this.selectedDate, 'dd/MM/yyyy')
    console.log("Value=" + this.selectedDate);
    // if (this.selectedDate!=="" && this.selectedDate !== undefined ) {
    //   let dt1 = new Date(this.selectedDate).toISOString();
    //   dt1 = dt1.split('T')[0];
    //   alert(dt1);
    //}
    this.GetData();
  }

  FilterData() {
    console.log(3);
    if (this.filterValue.length > 0 && this.selectedFilter.length > 0) {
      let value = this.filterValue;
      if (this.selectedFilter === "Title") {
        console.log(value);
        //var item = this.hardwareList.filter((item: { itemTitle: string; }) => item.itemTitle.valueOf("cc")>-1);
        this.hardwareList = this.hardwareList.filter((element: { itemTitle: string | any[]; }) => element.itemTitle.includes(value));
      }
      else if (this.selectedFilter === "BarCode") {
        console.log(value);
        this.hardwareList = this.hardwareList.filter((element: { itemCode: string | any[]; }) => element.itemCode === value);
      }
      else { }
    }

    if (this.selectedCheckingStatus.length > 0) {
      console.log(this.selectedCheckingStatus);
      if (this.selectedCheckingStatus === "Success") {
        var item = this.hardwareList.filter((item: { checkinstatus: string; }) => item.checkinstatus === "1");
        this.hardwareList = item;
      }
      else if (this.selectedCheckingStatus === "Failed") {
        var item = this.hardwareList.filter((item: { checkinstatus: string; }) => item.checkinstatus === "0");
        this.hardwareList = item;
      }
      else { }

      if (this.selectedDate !== "" && this.selectedDate !== undefined) {
        let dt1 = new Date(this.selectedDate).toISOString();
        let dt2 = dt1.split('T')[0];
        var item = this.hardwareList.filter((item: { scanedDate: string; }) => (item.scanedDate !== "" && item.scanedDate.split('T')[0] === dt2));
        this.hardwareList = item;

      }
    }
  }

  public ExportToExcel(): void {
    const fileName: string = "CheckingDetails";
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.hardwareList);
    const wb: XLSX.WorkBook = { Sheets: { 'data': ws }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    this.saveExcelFile(excelBuffer, fileName);
  }

  private saveExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: this.fileType });
    FileSaver.saveAs(data, fileName + this.fileExtension);
  }
}
