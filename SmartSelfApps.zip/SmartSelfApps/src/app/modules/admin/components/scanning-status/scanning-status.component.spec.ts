import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScanningStatusComponent } from './scanning-status.component';

describe('ScanningStatusComponent', () => {
  let component: ScanningStatusComponent;
  let fixture: ComponentFixture<ScanningStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ScanningStatusComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ScanningStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
