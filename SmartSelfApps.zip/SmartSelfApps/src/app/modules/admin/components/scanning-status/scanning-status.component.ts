import { Component, OnInit } from '@angular/core';
import { Subscription, switchMap, timer } from 'rxjs';
import { SacanningServiceService } from 'src/app/services/sacanning-service.service';

@Component({
  selector: 'app-scanning-status',
  templateUrl: './scanning-status.component.html',
  styleUrls: ['./scanning-status.component.css']
})
export class ScanningStatusComponent implements OnInit {
  public ScanningList: any;
  subscription !: Subscription;
  constructor(private _scanningService: SacanningServiceService) {
  }

  ngOnInit(): void {

    this._scanningService.getAll().subscribe((data) => {
      this.ScanningList = data;
    });

    this.GetData();
  }
  GetData() {
    this.subscription = timer(0, 10000).pipe(
      switchMap(() => this._scanningService.getAll())
    ).subscribe(data => {
      console.log("scanning completed.");
      this.ScanningList = data;
    }
    );
  }
  // GetData() {
  //   this._scanningService.getAll().subscribe((data) => {
  //     this.ScanningList = data;
  //   });
  // }
  

}
