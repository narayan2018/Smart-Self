import { Component, OnInit } from '@angular/core';
import { AuthService } from './../../../../services/auth.service';

import { Router } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  userName: string = ""
  todaydate: number = Date.now();
  user: any;
  IsAdmin: boolean = false;
  constructor(private _authService: AuthService) {

    setInterval(() => { this.todaydate = Date.now() }, 1);
  }

  ngOnInit(): void {
    this.getUser();
  }
  logout(): void {
    this._authService.logout();
  }
  getUser() {
    this.user = this._authService.getUser();
    if (this.user !== null || this.user !== "") {
      let data = JSON.parse(this.user);
      this.userName = data.userName;
      console.log(data.role);
      this.IsAdmin = data.role === "Admin" ? true : false;
    }
  }
}
