import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { EmailServiceService } from 'src/app/services/email-service.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  message: string = "";
  forgotPassForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email])
  });
  constructor(private emailservice: EmailServiceService, private router: Router) { }

  ngOnInit(): void {
  }
  valuechange(newValue:any) {
    console.log("value=" + newValue);
    if(newValue.trim()==="")
    {
      this.message="";
    }

  }
  onSubmit() {
    if (this.forgotPassForm.valid) {
      this.emailservice.SendPassword(this.forgotPassForm.value).subscribe(
        (result: any) => {
          console.log(result.status);
          if (result.status === "True") {
            this.message = "Your password has been sent to your email address."
          } else {
            this.message = "Invalid email address."
          }
        },
        (err: Error) => {
          this.message = err.message
        }
      );
    }
    else {
      this.message = "Invalid email address."
    }
  }
}
