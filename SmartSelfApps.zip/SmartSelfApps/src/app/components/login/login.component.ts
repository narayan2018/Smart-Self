import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  submitted = false;
  loginForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email, Validators.minLength(3)]),
    password: new FormControl('', [Validators.required, Validators.minLength(3)]),
  });
  constructor(private _authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    if (this._authService.isLoggedIn()) {
      this.router.navigate(['admin']);
    }
  }
  get f() { return this.loginForm.controls; }

  onSubmit(): void {
    this.submitted = true;
    if (this.loginForm.valid) {
      this._authService.login(this.loginForm.value).subscribe(
        (result: any) => {
          this._authService.setToken(result.token);
          this._authService.setUser(result.user);
          this.router.navigate(['/admin']);
        },
        (err: Error) => {
          alert("Login failed.");
        }
      );
    }
  }
}
