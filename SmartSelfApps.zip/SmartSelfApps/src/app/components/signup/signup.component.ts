import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  GenderList: any = ['Male', 'Female'];
  RoleList: any = ['Normal', 'Admin'];
  defaultGender: string = 'Male';
  defaultRole: string = 'Normal';
  signupForm: FormGroup;
  message: string = "";

  constructor(private _userService: UserServiceService) {
    this.signupForm = new FormGroup({
      username: new FormControl('', [Validators.required, Validators.minLength(2)]),
      password: new FormControl('', [Validators.required, Validators.minLength(3)]),
      email: new FormControl('', [Validators.required, Validators.email, Validators.minLength(3)]),
      mobileNumner: new FormControl('', [Validators.required, Validators.minLength(3)]),
      gender: new FormControl('', [Validators.required]),
      role: new FormControl('', [Validators.required]),
    });

    this.signupForm.controls['gender'].setValue(this.defaultGender, { onlySelf: true });
    this.signupForm.controls['role'].setValue(this.defaultRole, { onlySelf: true });
  }

  get f() { return this.signupForm.controls; }
  ngOnInit(): void {
    this.message = "";
  }


  Register() {
    this.message = ""
    //console.log(this.signupForm.value);

    if (this.signupForm.valid) {
      this._userService.signup(this.signupForm.value).subscribe(
        (res: any) => {
          console.log(res);
          if (res) {
            this.message = "User created sucessfully!"
          }
        }, (Error) => {
          alert("Sign up error");
        })
    }
    else {
      this.message = "Invalid data!"
    }
  }
}
