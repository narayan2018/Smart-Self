import { TestBed } from '@angular/core/testing';

import { SacanningServiceService } from './sacanning-service.service';

describe('SacanningServiceService', () => {
  let service: SacanningServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SacanningServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
