import { Observable, of, throwError } from 'rxjs';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  apiUrl: string = 'https://localhost:44331/api/User/';
  headers = new HttpHeaders().set('Content-Type', 'application/json');

  constructor(private router: Router, private http: HttpClient) {
  }

  setToken(token: string): void {
    localStorage.setItem('token', token);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  setUser(user: any): void {
    localStorage.setItem('user', JSON.stringify(user));
  }

  getUser(): string | null {
    return localStorage.getItem('user');;
  }
  isLoggedIn() {
    return this.getToken() !== null;
  }

  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    this.router.navigate(['login']);
  }

  login({ email, password }: any): Observable<any> {
    let data = { "password": password, "email": email };
    return this.http.post(this.apiUrl + 'Authenticate', data);
  }
}
