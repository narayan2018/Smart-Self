import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  headers = new HttpHeaders().set('Content-Type', 'application/json');
  apiUrl: string = 'https://localhost:44331/api/User/';

  constructor(private http: HttpClient, private _authService: AuthService) { }


  signup(req: any): Observable<any> {
    let signupData = {
      "id": 0,
      "username": req.username,
      "password": req.password,
      "email": req.email,
      "mobile": req.mobileNumner,
      "gender": req.gender,
      "role":req.role
    };
    const token = this._authService.getToken();
    this.headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    console.log(signupData);
    console.log(this.apiUrl + 'AddUser');
    return this.http.post(this.apiUrl + 'AddUser', signupData, { headers: this.headers });
  }
}
