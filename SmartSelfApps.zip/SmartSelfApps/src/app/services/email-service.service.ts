import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmailServiceService {
  apiUrl: string = 'https://localhost:44331/api/EmailService/';
  headers = new HttpHeaders().set('Content-Type', 'application/json');
  constructor(private http: HttpClient) { }

  SendPassword({ email }: any): Observable<any> {
    let data = { "email": email };
    return this.http.post(this.apiUrl + 'RetrivePassword', data);
  }
}
