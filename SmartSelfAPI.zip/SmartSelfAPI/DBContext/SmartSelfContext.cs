﻿using Microsoft.EntityFrameworkCore;
using SmartSelfAPI.Models;

namespace SmartSelfAPI.DBContext
{
    public class SmartSelfDBContext:DbContext
    {
        public SmartSelfDBContext(DbContextOptions<SmartSelfDBContext> options)
           : base(options)
        {
        }
        public DbSet<RawData> tblRawData { get; set; }

        public DbSet<CheckInDetail> tblCheckInDetail { get; set; }

        public DbSet<User> User { get; set; }
    }
}
