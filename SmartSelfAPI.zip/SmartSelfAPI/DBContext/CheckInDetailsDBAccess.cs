﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SmartSelfAPI.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace SmartSelfAPI.DBContext
{
    public class CheckInDetailsDBAccess
    {
        private readonly string _conStr;
        public CheckInDetailsDBAccess(IConfiguration config)
        {
            _conStr = "Server = localhost; Database = SONY; Trusted_Connection = True";
            _conStr = config.GetConnectionString("SmartSelfDBConnection");
        }
        public List<CheckInDetail> GetAllCheckInDetail()
        {
            var checkInDetail = new List<CheckInDetail>();

            string sql = "select * from [Person]";


            SqlCommand cmd = null;
            var con = new SqlConnection(_conStr);
            try
            {
                con.Open();
                cmd = new SqlCommand(sql, con);
                var dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    var item = new CheckInDetail();
                    item.Id = Convert.ToInt32(dataReader.GetValue(0));
                    item.ItemCode = Convert.ToString(dataReader.GetValue(1));
                    item.ReturnDate = Convert.ToDateTime(dataReader.GetValue(2));
                    item.ScanedDate = Convert.ToDateTime(dataReader.GetValue(3));
                    item.Shelfno = Convert.ToString(dataReader.GetValue(4));
                    item.Bayno = Convert.ToString(dataReader.GetValue(5));
                    item.Tierno = Convert.ToString(dataReader.GetValue(6));
                    item.ItemID = Convert.ToString(dataReader.GetValue(7));
                    item.ItemTitle = Convert.ToString(dataReader.GetValue(8));
                    item.Checkinstatus = Convert.ToString(dataReader.GetValue(9));
                    item.Message = Convert.ToString(dataReader.GetValue(10));
                    checkInDetail.Add(item);
                }
                dataReader.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con != null) con.Close();
                if (cmd != null) cmd.Dispose();
            }
            return checkInDetail;
        }
    }
}
