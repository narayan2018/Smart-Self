﻿using Microsoft.EntityFrameworkCore;
using SmartSelfAPI.DBContext;
using SmartSelfAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SmartSelfAPI.Repositories
{
    public class RawDataRepository: IRawDataRepository
    {

        private readonly SmartSelfDBContext _context;

        public RawDataRepository(SmartSelfDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<RawData>> GetAllRawData()
        {
            return await _context.tblRawData.ToListAsync();
        }
    }

    public interface IRawDataRepository
    {
        Task<IEnumerable<RawData>> GetAllRawData();
    }
}
