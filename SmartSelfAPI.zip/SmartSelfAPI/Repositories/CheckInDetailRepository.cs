﻿using Microsoft.EntityFrameworkCore;
using SmartSelfAPI.DBContext;
using SmartSelfAPI.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SmartSelfAPI.Repositories
{
    public class CheckInDetailRepository: ICheckInDetailRepository
    {
        private readonly SmartSelfDBContext _context;

        public CheckInDetailRepository(SmartSelfDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<CheckInDetail>> GetAllCheckInDetails()
        {
            try
            {
                return await _context.tblCheckInDetail.ToListAsync();
            }
            catch (Exception ex)
            {

            }
            return null;
        }
    }

    public interface ICheckInDetailRepository
    {
        Task<IEnumerable<CheckInDetail>> GetAllCheckInDetails();
    }
}
