﻿using Microsoft.EntityFrameworkCore;
using SmartSelfAPI.DBContext;
using SmartSelfAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SmartSelfAPI.Repositories
{
    public class UserRepository: IUserRepository
    {
        private readonly SmartSelfDBContext _context;

        public UserRepository(SmartSelfDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<User>> GetAllUsers()
        {
            return await _context.User.ToListAsync();
        }
        public async Task<User> Create(User user)
        {
            _context.User.Add(user);
            await _context.SaveChangesAsync();

            return user;
        }
    }
    public interface IUserRepository
    {
        Task<IEnumerable<User>> GetAllUsers();
        Task<User> Create(User user);
    }
}
