﻿using Microsoft.AspNetCore.Mvc;
using SmartSelfAPI.DBContext;
using SmartSelfAPI.Helper;
using System;
using System.Threading.Tasks;

namespace SmartSelfAPI.Repositories
{
    public class EmailServiceRepository : IEmailServiceRepository
    {
        private readonly IEmailService _emailService;

        public EmailServiceRepository(IEmailService emailService)
        {
            _emailService = emailService;
        }

        public bool RetrivePassword(string email)
        {
            try
            {
               bool s= _emailService.RetrivePassword(email);
               return s;
            }
            catch (Exception ex)
            {
                return true;
            }
        }
    }

    public interface IEmailServiceRepository
    {
        bool RetrivePassword(string email);
    }
}
