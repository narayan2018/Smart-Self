﻿namespace SmartSelfAPI.Response
{
    public class EmailResponse
    {
        public string status { get; set; }
    }
}
