﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SmartSelfAPI.Models
{
    public class RawData
    {
        [Key]
        public int Id { get; set; }
        public string Itemcode { get; set; }
        public DateTime? WhenRead { get; set; }
        public string Shelfno { get; set; }
        public string Bayno { get; set; }
        public string Tierno { get; set; }
        public DateTime? WhenReadDevice { get; set; }
        public string ItemID { get; set; }
    }
}
