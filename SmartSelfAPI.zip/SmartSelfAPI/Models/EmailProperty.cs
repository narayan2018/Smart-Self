﻿namespace SmartSelfAPI.Models
{
    public class EmailProperty
    {
        public string Email { get; set; }
    }
}
