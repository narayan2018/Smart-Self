﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SmartSelfAPI.Models
{
    public class CheckInDetail
    {
        [Key]
        public int Id { get; set; }
        public string ItemCode { get; set; }
        public DateTime? ReturnDate { get; set; }
        public DateTime? ScanedDate { get; set; }
        public string Shelfno { get; set; }
        public string Bayno { get; set; }
        public string Tierno { get; set; }
        public string ItemID { get; set; }
        public string ItemTitle { get; set; }
        public string Checkinstatus { get; set; }
        public string Message { get; set; }
    }
}
