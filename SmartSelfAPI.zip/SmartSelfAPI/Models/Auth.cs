﻿namespace SmartSelfAPI.Models
{
    public class Auth
    {
        public string token { get; set; }
        public User user { get; set; }
    }
}
