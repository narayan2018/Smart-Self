﻿using System.ComponentModel.DataAnnotations;

namespace SmartSelfAPI.Models
{
    public class Credential
    {
        [Required, MinLength(3)]
        public string Email { get; set; }
        [Required, MinLength(3)]
        public string Password { get; set; }
    }
}
