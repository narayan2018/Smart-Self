﻿using System.ComponentModel.DataAnnotations;

namespace SmartSelfAPI.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Required, MinLength(3)]
        public string UserName { get; set; }

        [Required, MinLength(3)]
        public string Password { get; set; }

        [Required,MinLength(3)]
        public string Email { get; set; }

        [Required]
        public string Mobile { get; set; }

        [Required]
        public string Gender { get; set; }

        [Required]
        public string Role { get; set; }
    }
}
