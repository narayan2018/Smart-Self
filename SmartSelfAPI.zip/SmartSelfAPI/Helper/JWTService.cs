﻿using Microsoft.IdentityModel.Tokens;
using SmartSelfAPI.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System;
using Microsoft.Extensions.Configuration;

namespace SmartSelfAPI.Helper
{
    public class JWTService
    {
        private readonly IConfiguration _configuration;
        private readonly string _key;
        private readonly string _subject;
        private readonly string _issuer;
        private readonly string _audience;

        public JWTService(IConfiguration config)
        {
            _configuration = config;
            _key = _configuration["Jwt:Key"];
            _subject = _configuration["Jwt:Subject"];
            _issuer = _configuration["Jwt:Issuer"];
            _audience = _configuration["Jwt:Audience"];
        }

        public string GenerateToken(User user)
        {
            //create claims details based on the user information
            var claims = new[] {
                        new Claim(JwtRegisteredClaimNames.Sub,_subject),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                        //new Claim("Id", user.Id.ToString()),
                        //new Claim("UserId", user.UserId),
                        //new Claim("UserName", user.UserName),
                        //new Claim("Email", user.Email)
                    };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_key));
            var signature = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                this._issuer,
               this._audience,
                claims,
                expires: DateTime.UtcNow.AddMinutes(10),
                signingCredentials: signature
                );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
