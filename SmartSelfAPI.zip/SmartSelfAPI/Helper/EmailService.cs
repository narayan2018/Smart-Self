﻿namespace SmartSelfAPI.Helper
{
    public class EmailService : IEmailService
    {
        public bool RetrivePassword(string email)
        {
            //var smtpClient = new SmtpClient("smtp.gmail.com")
            //{
            //    Port = 587,
            //    Credentials = new NetworkCredential("username", "password"),
            //    EnableSsl = true,
            //};
            //var mailMessage = new MailMessage
            //{
            //    From = new MailAddress("nsnarayan93@gmail.com"),
            //    Subject = "subject",
            //    Body = "<h1>Hello</h1>",
            //    IsBodyHtml = true,
            //};
            //mailMessage.To.Add(email);

            //smtpClient.Send(mailMessage);
            return true;
        }
    }

    public interface IEmailService
    {
        bool RetrivePassword(string email);
    }
}
