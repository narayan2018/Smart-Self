﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartSelfAPI.Models;
using SmartSelfAPI.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SmartSelfAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CheckInDetailController : ControllerBase
    {
        private readonly ICheckInDetailRepository _checkInDetailRepository;

        public CheckInDetailController(ICheckInDetailRepository checkInDetails)
        {
            _checkInDetailRepository = checkInDetails;
        }

        [HttpGet("GetAll")]
        public async Task<IEnumerable<CheckInDetail>> GetAllCheckInDetails()
        {   
           return await _checkInDetailRepository.GetAllCheckInDetails();
        }
    }
}
