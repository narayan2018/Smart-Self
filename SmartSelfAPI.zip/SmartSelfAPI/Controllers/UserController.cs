﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SmartSelfAPI.Helper;
using SmartSelfAPI.Models;
using SmartSelfAPI.Repositories;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmartSelfAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private IConfiguration _configuration;
        public UserController(IUserRepository userRepository, IConfiguration config)
        {
            _userRepository = userRepository;
            _configuration = config;
        }
        [AllowAnonymous]
        [HttpGet("GetAll")]
        public async Task<IEnumerable<User>> GetAllUsers()
        {
            return await _userRepository.GetAllUsers();
        }

        [AllowAnonymous]
        [HttpPost("Authenticate")]
        public async Task<IActionResult> Authenticate(Credential credential)
        {
            if (!string.IsNullOrEmpty(credential.Email) && !string.IsNullOrEmpty(credential.Password))
            {
                var result = await _userRepository.GetAllUsers();

                User user = result.Where(x => x.Email == credential.Email && x.Password == credential.Password).FirstOrDefault();

                if (user != null)
                {
                    var token = new JWTService(_configuration).GenerateToken(user);

                    var authRes = new Auth()
                    {
                        token = token,
                        user = user
                    };
                    return Ok(authRes);
                }
                else
                {
                    return Ok("Invalid credentials");
                }

            }
            else
            {
                return BadRequest();
            }
        }

        [HttpPost("AddUser")]
        public async Task<ActionResult<User>>AddUser([FromBody] User user)
        {
            var newBook = await _userRepository.Create(user);
            return newBook;
        }
    }
}
