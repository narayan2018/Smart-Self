﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartSelfAPI.Models;
using SmartSelfAPI.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SmartSelfAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RowDataController: ControllerBase
    {
        private readonly IRawDataRepository _rowDataRepository;

        public RowDataController(IRawDataRepository rawDataRepository)
        {
            _rowDataRepository = rawDataRepository;
        }

        [HttpGet("GetAll")]
        public async Task<IEnumerable<RawData>> GetAllRawData()
        {
            return await _rowDataRepository.GetAllRawData();
        }
    }
}
