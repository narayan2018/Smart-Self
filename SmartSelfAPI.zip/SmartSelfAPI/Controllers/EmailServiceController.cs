﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartSelfAPI.Models;
using SmartSelfAPI.Repositories;
using SmartSelfAPI.Response;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace SmartSelfAPI.Controllers
{
    //[Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class EmailServiceController: ControllerBase
    {
        private readonly IEmailServiceRepository _emailServiceRepository;
        private readonly IUserRepository _userRepository;

        public EmailServiceController(IEmailServiceRepository emailServiceRepository, IUserRepository userRepository)
        {
            _emailServiceRepository = emailServiceRepository;
            _userRepository = userRepository;
        }

        [HttpPost("RetrivePassword")]
        public async Task<ActionResult> RetrivePassword(EmailProperty emailProperty)
        {
            var res = new EmailResponse() { status = "false" };
            try
            {
                var users = await _userRepository.GetAllUsers();
                User user = users.Where(x => x.Email == emailProperty.Email).FirstOrDefault();
               
                if (user != null)
                {
                    var result = _emailServiceRepository.RetrivePassword(user.Email);
                    res.status = result.ToString();
                }
                else
                {
                    return Ok(res);
                }
            }
            catch(Exception)
            {

            }
            return Ok(res);
        }
    }
}
